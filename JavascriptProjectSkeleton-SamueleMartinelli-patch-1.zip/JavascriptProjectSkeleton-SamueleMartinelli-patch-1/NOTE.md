# User Story

Una user story è una frase che ha la forma

COME <RUOLO> VOGLIO <COSA>

Come utente voglio visualizzare la lista articoli


# CASI D'USO

Diagramma


# DIAGRAMMI DI SEQUENZA

[ ] AZIONE 1
  [ ] step 1
  [ ] step 2
  ....
